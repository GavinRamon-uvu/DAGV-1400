using UnityEngine;
public class ZigZagMovement : MonoBehaviour
{
    // Speed of forward movement
    public float speed = 5.0f;
    
    // Amplitude of the zigzag (how wide it moves horizontally)
    public float amplitude = 5.0f;
    
    //Frequency of the zigzag (how fast it zigzags horizontally)
    public float frequency = 1.0f;
    
    //Direction of forward movement
    public Vector2 forwardDirection = Vector3.forward;
    
    private float _startTime;

    void Start()
    {
        //Record the start time
        _startTime = Time.time;
    }

    void Update()
    {
        //Calculate forward movement 
        Vector3 forwardMovement = forwardDirection * (speed * Time.deltaTime);
        
        //Calculate the zigzag movement using a sine wave
        float zigzagoffset= Mathf.Sin(Time.time * frequency) * amplitude;
        
        //Create a zigzag movement vector along the x-axis
        Vector3 zigzagMovement = new Vector3(zigzagoffset, 0, zigzagoffset);
        
        //Apply the movement to the GameObject
        transform.transform.position +=forwardMovement + zigzagMovement;

    }
}
