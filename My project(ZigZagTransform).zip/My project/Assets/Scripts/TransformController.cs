using UnityEngine;
public class TransformController : MonoBehaviour
{
    private void Update()
    {
        //Move the target GameObject
        var x = Mathf.PingPong(Time.time * 2, 3);
        var p = new Vector3(x, 0, 0);
        transform.position = p;
        
    }
}
