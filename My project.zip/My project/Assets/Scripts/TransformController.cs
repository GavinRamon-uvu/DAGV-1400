using System.Collections;
using System.Collections.Generic;
using UnityEngine;

using UnityEngine;

public class TransformController : MonoBehaviour
{
    // Update is called once per frame
    private void Update()
    {
        // Move the target GameObject
        var x = Mathf.PingPong(Time.time, 3);  // PingPong for movement in X axis
        var p = new Vector3(x, 11, 0);  // Set the position
        transform.position = p;

        // Rotate the target GameObject
        float rotationSpeed = 1530f;  // Rotation speed
        transform.Rotate(Vector3.up, rotationSpeed * Time.deltaTime);  // Rotate around Y axis
    }
}
