using UnityEngine;
public class BouncyBall : MonoBehaviour
{
    
    public class BouncyBall : MonoBehaviour
    {
        // A reference to the Rigidbody component
        private Rigidbody rb;
    
        // Bounciness factor (you can adjust this to control how bouncy the ball is)
        public float bounceForce = 10f;
    
        // Gravity modifier to make the ball fall faster/slower (optional)
        public float gravityMultiplier = 1f;
    
        void Start()
        {
            // Get the Rigidbody component attached to this GameObject
            rb = GetComponent<Rigidbody>();
    
            // Apply the gravity multiplier
            rb.mass *= gravityMultiplier;
        }
    
        // This function is called when the ball collides with something
        private void OnCollisionEnter(Collision collision)
        {
            // Check if the collision was with a surface (like the ground)
            if (collision.contacts.Length > 0)
            {
                // Get the collision contact point and normal
                ContactPoint contact = collision.contacts[0];
    
                // Calculate the bounce direction using the normal of the surface
                Vector3 bounceDirection = Vector3.Reflect(rb.velocity, contact.normal);
    
                // Apply bounce force
                rb.velocity = bounceDirection.normalized * bounceForce;
    
                // Optional debug log to show the collision information
                Debug.Log("Bounced off " + collision.gameObject.name);
            }
        }
    }

