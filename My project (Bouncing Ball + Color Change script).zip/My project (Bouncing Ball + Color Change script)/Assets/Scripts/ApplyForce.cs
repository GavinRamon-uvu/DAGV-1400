using UnityEngine;

public class ApplyForce : MonoBehaviour
{
    private Rigidbody _rb;

    private void Start()
    {
        // Get the Rigidbody component attached to this GameObject
        _rb = GetComponent<Rigidbody>();
        // Apply a force to the Rigidbody
        _rb.AddForce(Vector3.right * 500);
    }

    // OnCollisionEnter should have a capital O, to match Unity's naming conventions
    private void OnCollisionEnter(Collision collision)
    {
        // Log collision information to the console
        Debug.Log("Collision detected with " + collision.gameObject.name);
    }
}