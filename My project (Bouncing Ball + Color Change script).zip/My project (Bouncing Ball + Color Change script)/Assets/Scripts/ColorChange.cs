using UnityEngine;

public class NewBehaviourScript : MonoBehaviour
{
using UnityEngine;

public class ColorChange : MonoBehaviour
{
    // Define the new color that will be applied on collision
    public Color newColor = Color.red;

    // This method is called when the object collides with another GameObject
    void OnCollisionEnter(Collision collision)
    {
        // Change the object's color upon collision with another GameObject
        GetComponent<Renderer>().material.color = newColor;
    }
}